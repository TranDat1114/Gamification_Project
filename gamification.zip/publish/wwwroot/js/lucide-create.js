window.LucideCreate = () => {
    lucide.createIcons();
}